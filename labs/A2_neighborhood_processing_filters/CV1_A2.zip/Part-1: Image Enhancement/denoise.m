function [ imOut ] = denoise( image, kernel_type, varargin)

switch kernel_type
    case 'box'
        fprintf('Not implemented\n')
    case 'median'
        fprintf('Not implemented\n')
    case 'gaussian'
        fprintf('Not implemented\n')
end
end
